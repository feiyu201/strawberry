<?php

return array (
  'wenben' => 
  array (
    'title' => '文本框:',
    'type' => 'text',
    'value' => '1302274444222',
  ),
  'danxuan' => 
  array (
    'title' => '单选:',
    'type' => 'radio',
    'options' => 
    array (
      1 => '显示',
      0 => '不显示',
    ),
    'value' => '0',
  ),
  'duoxuan' => 
  array (
    'title' => '多选:',
    'type' => 'checkbox',
    'options' => 
    array (
      1 => 'A',
      2 => 'B',
      3 => 'C',
      4 => 'D',
    ),
    'value' => '1,2,4',
  ),
  'xuanzekuang' => 
  array (
    'title' => '选择框:',
    'type' => 'select',
    'options' => 
    array (
      1 => 'A',
      2 => 'B',
      3 => 'C',
      4 => 'D',
    ),
    'value' => '3',
  ),
  'wenbuyu' => 
  array (
    'title' => '文本域:',
    'type' => 'textarea',
    'value' => '这里是描23424述',
  ),
);
