<?php
namespace app\common\library;

class Category{

    public function getList(){

    }
}