<?php
/**
 * +----------------------------------------------------------------------
 * | 角色组管理模型
 */
namespace app\common\model;

// 引入框架内置类
use think\facade\Request;

class AuthGroup extends Base
{
    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';

   

}