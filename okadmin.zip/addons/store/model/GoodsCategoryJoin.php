<?php
namespace addons\store\model;

use think\Model;

class GoodsCategoryJoin extends Model
{
    protected $pk = 'id';

    protected static function init(){

    }
}
