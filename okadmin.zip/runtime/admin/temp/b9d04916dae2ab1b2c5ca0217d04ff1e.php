<?php /*a:1:{s:53:"E:\phpstudy\WWW\okadmin\app\admin\view\admin\add.html";i:1600511481;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>添加用户</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="/static/css/oksub.css">
	<script type="text/javascript" src="/static/lib/loading/okLoading.js"></script>
	<style>
		.layui-upload-list img{
			height:100px;
			width:100px;
		}
	</style>
</head>
<body>
<div class="ok-body">
	<!--form表单-->
	<form class="layui-form layui-form-pane ok-form">
		
		 
		<div class="layui-form-item">
			
			<div class="layui-input-block">
				<div class="layui-upload">
				  <button type="button" class="layui-btn" id="test1">上传头像</button>
				  <div class="layui-upload-list">
				    <img class="layui-upload-img" id="demo1">
				    <p id="demoText"></p>
					<input type="hidden" name="avatar">
				  </div>
				</div> 
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">用户名</label>
			<div class="layui-input-block">
				<input type="text" name="username" placeholder="请输入用户名" autocomplete="off" class="layui-input"
				       lay-verify="required">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">昵称</label>
			<div class="layui-input-block">
				<input type="text" name="nickname" placeholder="请输入昵称" autocomplete="off" class="layui-input" lay-verify="required">
			</div>
		</div>
		
		<div class="layui-form-item">
			<label class="layui-form-label">邮箱</label>
			<div class="layui-input-block">
				<input type="text" name="email" placeholder="请输入邮箱" autocomplete="off" class="layui-input"
				       lay-verify="email">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">密码</label>
			<div class="layui-input-block">
				<input type="password" name="password" placeholder="请输入密码" autocomplete="off" class="layui-input"
				       lay-verify="required">
			</div>
		</div>
		
		
		
		<div class="layui-form-item">
			<label class="layui-form-label">状态</label>
			<div class="layui-input-block">
				<input type="checkbox" name="status" lay-skin="switch" lay-text="启用|停用" checked value="1">
			</div>
		</div>
		
		
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" lay-submit lay-filter="add">立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
			</div>
		</div>
	</form>
</div>
<!--js逻辑-->
<script src="/static/lib/layui/layui.js"></script>
<script>
	
	
	
	layui.use(["element", "form", "laydate", "okLayer", "okUtils"], function () {
		let form = layui.form;
		let laydate = layui.laydate;
		let okLayer = layui.okLayer;
		let okUtils = layui.okUtils;

		okLoading.close();

		//laydate.render({elem: "#birthday", type: "datetime"});

		form.verify({
			
		});

		form.on("submit(add)", function (data) {
			okUtils.ajax("<?php echo url('add'); ?>", "post", data.field, true).done(function (response) {
				//console.log(response);
				if(response.code==1){
					okLayer.greenTickMsg("添加成功", function () {
						parent.layer.close(parent.layer.getFrameIndex(window.name));
					});
				}else{
					okLayer.greenTickMsg(response.msg, function () {
				        
				    })
				}
				
			}).fail(function (error) {
				console.log(error)
			});
			return false;
		});
	});
</script>


<script>
layui.use('upload', function(){
  var $ = layui.jquery
  ,upload = layui.upload;
  
  //普通图片上传
  var uploadInst = upload.render({
    elem: '#test1'
    ,url: '<?php echo url("admin/upload/index"); ?>' //改成您自己的上传接口
    ,before: function(obj){
      //预读本地文件示例，不支持ie8
      obj.preview(function(index, file, result){
        $('#demo1').attr('src', result); //图片链接（base64）
      });
    }
    ,done: function(res){
      //如果上传失败
      if(res.code > 0){
        return layer.msg('上传失败');
      }
	  console.log(res);
      //上传成功
	  $('input[name=avatar]').val(res.path);
    }
    ,error: function(){
      //演示失败状态，并实现重传
      var demoText = $('#demoText');
      demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
      demoText.find('.demo-reload').on('click', function(){
        uploadInst.upload();
      });
    }
  });

  
});
</script>
</body>
</html>
